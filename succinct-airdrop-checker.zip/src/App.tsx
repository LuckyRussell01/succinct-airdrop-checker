
import React, { useState } from "react";
import axios from "axios";
import { ethers } from "ethers";

const STAKING_CONTRACT = "0x837d40650ab3b0aa02e7e28238d9fea73031856c";
const ABI = ["function balanceOf(address) view returns (uint256)"];

const provider = new ethers.providers.JsonRpcProvider("https://sepolia.infura.io/v3/975931270bb04edb9937031a5217896b");

function App() {
  const [addr, setAddr] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  async function handleCheck() {
    if (!ethers.utils.isAddress(addr)) {
      alert("Invalid Ethereum address");
      return;
    }
    setLoading(true);

    try {
      let totalProves = 0;
      let totalStars = 0;
      const stages = [1, 2, 2.5];

      for (const stage of stages) {
        const res = await axios.get(`https://testnet.succinct.xyz/api/stage/${stage}/wallet/${addr}`);
        const data = res.data;
        totalProves += data.proves || 0;
        totalStars += data.stars || 0;
      }

      const contract = new ethers.Contract(STAKING_CONTRACT, ABI, provider);
      const stakeBig = await contract.balanceOf(addr);
      const stake = ethers.utils.formatUnits(stakeBig, 18);

      const score = totalProves + totalStars;
      const maxScore = 1000;
      const maxDist = ethers.utils.parseUnits("1000000", 18);
      const share = ethers.BigNumber.from(score).mul(maxDist).div(maxScore);
      const airdrop = ethers.utils.formatUnits(share, 18);

      setResult({ totalProves, totalStars, stake, airdrop });
    } catch (err) {
      console.error(err);
      alert("Error fetching data.");
    }

    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-succinct-light flex items-center justify-center p-4">
      <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full">
        <img src="/logo.jpg" alt="Succinct Logo" className="h-16 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-succinct-pink mb-4">Succinct $PROVE Airdrop Checker</h1>
        <input
          type="text"
          placeholder="Enter Ethereum address"
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          className="w-full border px-3 py-2 rounded mb-4"
        />
        <button
          onClick={handleCheck}
          disabled={loading}
          className="w-full bg-succinct-pink text-white py-2 rounded hover:bg-pink-600"
        >
          {loading ? "Checking..." : "Check Eligibility"}
        </button>
        {result && (
          <div className="mt-6 text-gray-700">
            <p><strong>Proves:</strong> {result.totalProves}</p>
            <p><strong>Stars:</strong> {result.totalStars}</p>
            <p><strong>Staked:</strong> {result.stake} tokens</p>
            <p><strong>Airdrop:</strong> {result.airdrop} $PROVE</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
