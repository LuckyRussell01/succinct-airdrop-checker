
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        succinct: {
          pink: "#FF6AD5",
          light: "#FFE0F5",
        },
      },
    },
  },
  plugins: [],
}
